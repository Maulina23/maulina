<html>
    <head>
        <title>Halaman Beranda</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>
    <body>
      <header>
        <ul>
          <a href="index.php"><li>Beranda</li></a>
          <a href="artikel.php"><li>Artikel</li></a>
          <a href="keluar.php"><li>keluar</li></a>


            <div class="img">
      <a target="blank" href="03.jpg">
      <img src="2.jpg" alt="Trolltunga Norway"  width="400" height="400">
      <a target="blank" href="04.jpg">
      <img src="7.jpg" alt="Trolltunga Norway"  width="256" height="500">
      <a target="blank" href="05.jpg">
      <img src="9.jpg" alt="Trolltunga Norway"  width="400" height="500">
      <a target="blank" href="07.jpg">
      <img src="23.jpg" alt="Trolltunga Norway"  width="456" height="500">

        </ul>
      </header>

      <section>
        <center>
            <font style="font-size:36px;color:black;font-family:justiceleague;">Selamat Datang di halaman Beranda</font>
        </center>
      </section>

    </body>
</html>
