<!DOCTYPE html>
<html>
  <head>
    <title>Halaman Login</title>
    <style type="text/css">
  body{
        font-family: arial;
        font-size: 14px;
        background-image: url(kui.jpg);
        background-size: cover;
  }
  #utama{
          width:300px;
          margin: 0 auto;
          margin-top: 12%;
  }
  .judul{
        padding: 15px;
        text-align: center;
        color: #fff;
        font-size: 20px;
        background-color: #66cc33;
        border-top-right-radius: 10px;
        border-bottom-left-radius: 10px;
        border-bottom: 3px solid #66cc33;
  }
  .inputan{
            background-color: #ffc4f5;
            padding: 20px;
            border-bottom-right-radius: 10px;
            border-bottom-left-radius: 10px;
  }
  input{
        padding:10px;
        border:0;
  }
  .lg{
      width: 240px;
  }
.btn{
    background-color: #66cc33;
    border-radius: 10px;
    color: #fff;
    width: 240px;
}
.btn:hover{
  background-color: #66cc33;
  cursor: pointer;
}
</style>
</head>
<body>
      <div id="utama">
        <h1 class="judul">Halaman Login</h1>
        <form class="inputan" action="masuk.php" method="post">
          <table>
              <tr>
                  <td><input type="text" name="username" value="" placeholder="username" class="lg"></td>
                </tr>
                <tr style="margin-top:10px">
                    <td><input type="password" name="password" value="" placeholder="pasword" class="lg"></td>
                  </tr>
                  <tr style="margin-top:10px; text-align:center;">
                      <td><input type="submit" name="submit" value="submit" class="btn"></td>
