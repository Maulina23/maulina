<!DOCTYPE html>
<html>
    <head>

      <title>Register</title>
    </head>
    <body>
        <form class="" action="" method="post">
            <table>
                <tr>
                    <td>username</td>
                    <td><input type="text" name="username" value=""></td>
                  </tr>
                  <tr>
                      <td>Password</td>
                      <td><input type="password" name="password" value=""
                        ></td>
                </tr>
                <tr>
                    <td><a href="masuk.php">Halaman Login</a>></td>
                    <td><input type="submit" name="submit" value="submit"></td>
                  </tr>
                </table>
              </form>

  </body>
</html>
<?php
 include 'function.php';

 if(@$_POST['submit']) {


   $username=@$_POST['username'];
   $passworda=@$_POST['password'];
   $password=md5($passwoda);

   mysqli_query($connect,"INSERT INTO user(username,password)VALUES('$username','$password')");

  ?>
  <script type="text/javascript">
    alert("data tersimpan");
    window.location.href="masuk.php"
    </script>
    <?php
 }
