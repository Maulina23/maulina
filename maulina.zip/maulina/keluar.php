<?php
include 'masuk.php';
session_strat();
if (seassion_destroy()) {
  header ("location:masuk.php")
}
?>
