<html>
    <head>
        <title>Halaman Beranda</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>
    <body>
      <header>
        <ul>
          <a href="index.php"><li>Beranda</li></a>
          <a href="artikel.php"><li>Artikel</li></a>
          <a href="keluar.php"><li>Keluar</li></a>

        </ul>
      </header>

      <section>
        <center>
            <font style="font-size:40px;">Selamat Datang</font>

      <p>Satpam :aduh, duh, tiap hari adaa saja maling yg ketangkep, gak maling ayamlaah, maling motorlah maling jemuranlah, sampe-sampe maling…

<br>PuCin :wanita,,… ohh.. begituindahdipandang..itulahygmembuatakuterpesona, karenawajahwanitasangatcantikseperti...

<br>
<br>Bibi Kantin :cabe 10kilo,, begitupedaass. Begitumenggelora. Huahh..iniadalahbahan paling penting. Tidakdapatdipungkiri. Semua orang suka...

<br>Satpam :maling-malingygberkeliaran,, setiapharisayaberpatroli, kelilingkesanakemari, untukmenangkapmaling-malingitu. jikasayamelihatmaling, makasayaakanberteriakwoooy. maliing…

<br>PuCin :akucintakamuu..,, akutakakanmelupakanmu. ingatkahkamusewaktukitapertama kali bertemu? akuakanselaluingatmomenitu. ketikaitu..akutaksengajamenciuumm…

<br>Tsampah :comberanygbau,, sayasudahterbiasadenganitu. Ituadalahkendalaygsayatemuiketikasayamengaduk-aduksampah di…

<br>Koki :penggorengan,, siip. Penggorengansudahada. Tapikurangsatualatlagi. sayalupadimanameletakkanalatitu. Padahalsayatidakbisamenggorengtanpapenggorengandan...


<br>Satpam : pistol,, bilamalingtidakterkejarolehsaya, yahh, apabolehbuat. Pistol iniygakansayagunakanuntukmenembak…


<br>Tsampah :ketikakecilakudibuang di tumpukansampah,, Hiks.hiks. itulah masa laluku. kemudianseorangpemulung yang baikhatimengambildanmerawatku. akuinginmengucapkanpadanya: terimakasih. berkatkau, sekarang…

<br>Koki :spatulakusudahketemu,, yes.yes. nah… kalobeginikanenak. Sayabisamulaimemasak. ikutinya. pertama-tama, sediakanbahan-bahannya. lalu, masukan.…


<br>Satpam :pentungan, pistol, pisau, senter..oke. siapuntukpatrolimalamini. Hei! tampaknya di dindingsebelahsanaadaseseorangygygmasukkedalamsekolah! Akuberlarimengejarnyadantiba-tiba…

<br>PuCin :punyakuberdiri!,, tidak.. akusudahterlalujauhmengkhayaltentangwanita. inidosa. akuharusmembacabukuuntukmengalihkanpikiranku. laludengancepatakumeraba-raba…


<br>Tsampah :isicelanaku,, di celanakuini.. hanyaadabeberapa keeping uangratusan..akuinginsekalimembelikanmainanuntukanakku, yaitu…


<br>Koki :pisau,, sangattajamdanmengkilat. akuingatakusangatmembutuhkanini. Akumulaimencincangbahan-bahan. Wow. Pastimasakankunantiakanterasa...


<br>Satpam :kurangasem!!! kemanamalingtadi, awasyakalodapetakansaya….


<br>PuCin :ungkapkancintakepadanya,, inginsekaliakumengungkapkanisihatiku.. tetapimulutkuterasa...


<br>Tsampah :berbautaksedap,, ugh. dandipenuhilalat pula. Astaghfirullah. inimakananbasi. tapihanyaini yang bisaakuberikanuntukkeluargakuhariini..sabaryaanakistriku.. Orang sabar di akhiratnantiakanmasuk...


<br>Koki :kedalam oven,, setelahitu, sambilmenunggu, kitamempersiapkanhal yang lainnya, oke? supayaketikaayamsudahmatangakandihidangkanbersama….


<br>Satpam :babi!!! cepetbangetilangnyatumaling. Eh. Apaitu. Akumendengarsuarajejaklangkah kaki tepat di belakangku. padasaatitudadakuterasa…

<br>PuCin :menonjol,, itulah yang membuatkujaditakkonsentrasi. Sudahcukup. Akutaktahanlagi. kalaubegitulangsungsajaakuakanmeraba-raba...


<br>Tsampah :dinding masjid,, akuberusahamencarisaklarpadadinding masjid. akuinginberdoa. YaAllah..akumohonkepadamu. Mudahkanlahakudalam...


<br>Koki :menghidangkanmakanan,, agar makanantetaplezatmakakitahidangkanselagipanas. Hmm..mulutkurasanyasudahtaksabarlagiuntuk….


<br>PuCin :katakan I Love You,, setelahsekian lama berjuang.. dengansedikitkeberanian..akhirnyaakubisamengatakan kata-kata itudengan…


<br>Tsampah :khusyu’,, akuterus-menerusberdo’a. sampai-sampaitakterasadarimatakumenetes…


<br>Koki :kuah sop,, inidia yang bikinmasakankudisukaibanyak orang.. kalian tahuapa yang orang-orang bilangsetelahmakanmasakanku? Merekabilang...


<br>Tsampah :astaghfirullah,, ya Allah yatuhanku, ampunilahaku, berikanlahakupetunjukuntuk…
</p>
        </center>
      </section>

      <footer>
        Copyright &copy; 2018 Maulina Catur Wulandari X RPL 1.
      </footer>

    </body>
</html>
